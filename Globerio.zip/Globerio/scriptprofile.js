document.getElementById("person-btn").addEventListener("click", () => {
    document.getElementById("person-dropdown").classList.toggle("hidden");
  });
  
  function selectPerson(num) {
    document.getElementById("person-btn").textContent = `Person ${num}`;
    document.getElementById("person-dropdown").classList.add("hidden");
  }
  