export default class ModalView {
    constructor(modalId) {
      this.modal = document.getElementById(modalId);
      this.image = document.getElementById("modalMainImage");
      this.title = document.getElementById("modalTitle");
      this.price = document.getElementById("modalPrice");
      this.closeBtn = document.getElementById("modalCloseBtn");
      this.treasureContainer = document.getElementById("treasurePackages");
      this.touristSpots = document.getElementById("touristSpotsGallery");
  
      this.closeBtn.addEventListener("click", () => this.hide());
      this.modal.addEventListener("click", (e) => {
        if (e.target === this.modal) this.hide();
      });
    }
  
    show(spot, persons = 1) {
        this.image.src = spot.image;
        this.title.textContent = `${spot.hotel} + ${spot.airline}`;
        this.price.textContent = `$${spot.price * persons} for ${persons} ${persons > 1 ? "people" : "person"} • ${spot.city}, ${spot.country}`;
        this.renderTreasures();
        this.renderTouristSpots(spot);
        this.modal.classList.remove("hidden");
        const bookBtn = document.querySelector(".modal-book-btn");
        bookBtn.onclick = () => {
            const bookingModal = document.getElementById("bookingModal");
            const modalPrice = document.getElementById("modalPrice").textContent;
            const priceMatch = modalPrice.match(/\d+/);
            const basePrice = priceMatch ? parseFloat(priceMatch[0]) : spot.price;
            
            document.getElementById("bookingImage").src = spot.image;
            document.getElementById("bookingTitle").textContent = `${spot.hotel} - ${spot.city}, ${spot.country}`;
            document.getElementById("bookingDays").value = 2;
            document.getElementById("bookingDate").value = "";
            
            document.getElementById("bookingModal").classList.remove("hidden");

                document.getElementById("bookingCloseBtn").addEventListener("click", () => {
                document.getElementById("bookingModal").classList.add("hidden");
            });
    
          updateBookingTotal(basePrice);
          this.setupUserPostSystem();
        };
    }
  
    hide() {
      this.modal.classList.add("hidden");
    }
  
    renderTreasures() {
      this.treasureContainer.innerHTML = "";
      const treasures = [
        { name: "Spa Package", price: 120 },
        { name: "Romantic Dinner", price: 200 },
        { name: "City Tour", price: 150 }
      ];
  
      treasures.forEach(t => {
        const div = document.createElement("div");
        div.className = "treasure-card";
        div.textContent = `${t.name} - $${t.price}`;
        this.treasureContainer.appendChild(div);
      });
    }
  
    renderTouristSpots(spot) {
        this.touristSpots.innerHTML = "";
        const images = spot.nearbyAttractions || [];
      
        images.forEach(src => {
          const img = document.createElement("img");
          img.src = src;
          img.alt = "Nearby attraction";
          img.style.borderRadius = "8px";
          img.style.width = "100%";
          img.style.objectFit = "cover";
          this.touristSpots.appendChild(img);
        });
    }
      

    setupUserPostSystem() {
        const photoInput = document.getElementById("userPhotoInput");
        const commentInput = document.getElementById("userCommentInput");
        const postBtn = document.getElementById("postUserPhotoBtn");
        const feed = document.getElementById("userPhotosFeed");
      
        // Limpa feed
        feed.innerHTML = "";
      
        const user = {
          name: "John Doe",
          avatar: "https://ui-avatars.com/api/?name=John+Doe"
        };
      
        postBtn.onclick = () => {
          const file = photoInput.files[0];
          const comment = commentInput.value.trim();
      
          if (!file && !comment) return;
      
          const reader = new FileReader();
          reader.onload = function(e) {
            const postDiv = document.createElement("div");
            postDiv.className = "user-photo-card";
      
            postDiv.innerHTML = `
              <div class="user-info">
                <img src="${user.avatar}" style="width:32px;height:32px;border-radius:50%;margin-right:8px;vertical-align:middle;">
                <strong>${user.name}</strong>
              </div>
              ${file ? `<img src="${e.target.result}" alt="User Photo">` : ""}
              ${comment ? `<div class="comment-section"><p class="comment">${comment}</p></div>` : ""}
            `;
      
            feed.prepend(postDiv);
            photoInput.value = "";
            commentInput.value = "";
          };
      
          if (file) {
            reader.readAsDataURL(file);
          } else {
            reader.onload(); 
          }
        };
    }         
}
