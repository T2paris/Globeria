export default class DestinationView {
    constructor(mostPickedId, personalizedId) {
      this.mostPickedContainer = document.getElementById(mostPickedId);
      this.personalizedContainer = document.getElementById(personalizedId);
    }
  
    renderList(spots, container, onClick) {
        container.innerHTML = "";
      
        if (!Array.isArray(spots) || spots.length === 0) {
          const noResults = document.createElement("p");
          noResults.textContent = "No destinations found.";
          noResults.style.fontStyle = "italic";
          container.appendChild(noResults);
          return;
        }
      
        spots.forEach(spot => {
          const div = document.createElement("div");
          div.className = "combo-card";
      
          const isFlightOnly = spot.type === "flight";
          const title = isFlightOnly ? spot.airline : `${spot.hotel} + ${spot.airline}`;
      
          const imgSrc = spot.image && spot.image !== "" 
            ? spot.image 
            : "https://placehold.co/240x160/94a3b8/ffffff?text=No+Image";
      
          div.innerHTML = `
            <img src="${imgSrc}" alt="${spot.city}" loading="lazy" />
            <h4>${title}</h4>
            <p class="combo-dest">${spot.city}, ${spot.country}</p>
            <p class="combo-price">$${spot.price}</p>
          `;
      
          div.addEventListener("click", () => {
            if (typeof onClick === "function") {
              onClick(spot);
            }
          });
      
          container.appendChild(div);
        });
    }      
  
    renderMostPicked(spots, onClick) {
      this.renderList(spots, this.mostPickedContainer, onClick);
    }
  
    renderOnlyForYou(spots, onClick) {
      this.renderList(spots, this.personalizedContainer, onClick);
    }

  
    createCard(spot, onClickCallback) {
      const div = document.createElement("div");
      div.className = "destination-card";
  
      div.innerHTML = `
        <img src="${spot.image}" alt="${spot.city}">
        <h3>${spot.hotel}</h3>
        <p>${spot.city}, ${spot.country}</p>
        <p>$${spot.price}</p>
        <button class="btn">View More</button>
      `;
  
      div.querySelector("button").addEventListener("click", () => onClickCallback(spot));
      return div;
    }
  }
  