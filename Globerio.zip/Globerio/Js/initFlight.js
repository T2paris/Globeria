import TouristicSpotModel from "./Models/TouristicSpotModel.js";
import DestinationView from "./Views/DestinationView.js";
import ModalView from "./Views/ModalView.js";

const model = new TouristicSpotModel();
const view = new DestinationView("mostPickedContainer", "onlyForYouContainer");
const modal = new ModalView("travelModal");

let selectedPersons = 1;

// Apenas voos
const allFlights = model.getAllFlights();

// Renderiza os voos na seção "Choose Your Vacation"
view.renderMostPicked(allFlights, spot => modal.show(spot, selectedPersons));

// Botão de busca para voos
document.getElementById("searchBtn").addEventListener("click", () => {
  const country = document.getElementById("countrySelect").value;
  selectedPersons = Number(document.getElementById("personSelect").value) || 1;

  if (!country) {
    alert("Select a country!");
    return;
  }

  const flightsByCountry = model
    .getByCountry(country)
    .filter(s => s.type === "flight");

  if (flightsByCountry.length === 0) {
    alert(`No flights found for ${country}`);
  }

  view.renderMostPicked(flightsByCountry, spot => modal.show(spot, selectedPersons));
});

const userProfile = { preferredCategories: [] }; // assuming this is defined elsewhere

// Atualizar contadores
document.getElementById("userCount").textContent = "5241";
document.getElementById("photoCount").textContent = "1294";
document.getElementById("cityCount").textContent = "87";


function updateBookingTotal(basePrice) {
    const days = parseInt(document.getElementById("bookingDays").value) || 1;
    const packageType = document.getElementById("bookingPackage").value;
  
    let multiplier = 1;
    if (packageType === "flight") multiplier = 0.6;
    if (packageType === "hotel") multiplier = 0.8;
  
    const total = basePrice * days * multiplier;
    document.getElementById("bookingTotal").textContent = `You will pay: $${total.toFixed(2)} USD for `;
    document.getElementById("bookingDayCount").textContent = `${days} Day${days > 1 ? "s" : ""}`;
}

document.getElementById("bookingDays").addEventListener("input", () => {
    const price = parseFloat(document.getElementById("modalPrice").textContent.match(/\d+/)[0]);
    updateBookingTotal(price);
});
  
document.getElementById("bookingPackage").addEventListener("change", () => {
    const price = parseFloat(document.getElementById("modalPrice").textContent.match(/\d+/)[0]);
    updateBookingTotal(price);
});
  
