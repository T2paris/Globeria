export default class TouristicSpotModel {
  constructor() {
    this.spots = [
      // Hotéis - França
      {
        id: 1,
        hotel: "Hôtel du Louvre",
        airline: "Air France",
        city: "Paris",
        country: "France",
        price: 650,
        category: "City",
        type: "hotel",
        image: "IMG/Hôtel du Louvre.png",
        nearbyAttractions: [
          "/Img/Cathedrale Notre-Dame de Paris.png",
          "/Img/Musee d'Orsay.png",
          "/Img/Sainte-Chapelle.png"
        ]
      },
      {
        id: 2,
        hotel: "Hotel Le Meurice",
        airline: "Air France",
        city: "Paris",
        country: "France",
        price: 720,
        category: "City",
        type: "hotel",
        image: "IMG/Hotel Le Meurice.png",
        nearbyAttractions: [
          "https://upload.wikimedia.org/wikipedia/commons/5/5e/Tour_Eiffel_Wikimedia_Commons.jpg",
          "https://upload.wikimedia.org/wikipedia/commons/a/aa/Louvre_Museum_Wikimedia_Commons.jpg",
          "https://upload.wikimedia.org/wikipedia/commons/8/85/Cathedrale_Notre-Dame_de_Paris.jpg"
        ]
      },
      {
        id: 3,
        hotel: "Shangri-La Paris",
        airline: "Air France",
        city: "Paris",
        country: "France",
        price: 690,
        category: "Luxury",
        type: "hotel",
        image: "IMG/Shangri-La Paris.png",
        nearbyAttractions: [
          "/Img/Cathedrale Notre-Dame de Paris.png",
          "/Img/Musee d'Orsay.png",
          "/Img/Sainte-Chapelle.png"
        ]
      },

      // Hotéis - Japão
      {
        id: 4,
        hotel: "Park Hyatt Tokyo",
        airline: "ANA",
        city: "Tokyo",
        country: "Japan",
        price: 720,
        category: "City",
        type: "hotel",
        image: "IMG/Park Hyatt Tokyo.png",
        nearbyAttractions: [
          "https://upload.wikimedia.org/wikipedia/commons/5/5e/Tour_Eiffel_Wikimedia_Commons.jpg",
          "https://upload.wikimedia.org/wikipedia/commons/a/aa/Louvre_Museum_Wikimedia_Commons.jpg",
          "https://upload.wikimedia.org/wikipedia/commons/8/85/Cathedrale_Notre-Dame_de_Paris.jpg"
        ]
      },
      {
        id: 5,
        hotel: "The Ritz-Carlton Tokyo",
        airline: "ANA",
        city: "Tokyo",
        country: "Japan",
        price: 800,
        category: "Luxury",
        type: "hotel",
        image: "IMG/The Ritz-Carlton Tokyo.png",
        nearbyAttractions: [
          "https://upload.wikimedia.org/wikipedia/commons/5/5e/Tour_Eiffel_Wikimedia_Commons.jpg",
          "https://upload.wikimedia.org/wikipedia/commons/a/aa/Louvre_Museum_Wikimedia_Commons.jpg",
          "https://upload.wikimedia.org/wikipedia/commons/8/85/Cathedrale_Notre-Dame_de_Paris.jpg"
        ]
      },

      // Hotéis - EUA
      {
        id: 6,
        hotel: "The Plaza Hotel",
        airline: "Delta",
        city: "New York",
        country: "USA",
        price: 630,
        category: "City",
        type: "hotel",
        image: "IMG/The Plaza Hotel.png",
        nearbyAttractions: [
          "https://upload.wikimedia.org/wikipedia/commons/5/5e/Tour_Eiffel_Wikimedia_Commons.jpg",
          "https://upload.wikimedia.org/wikipedia/commons/a/aa/Louvre_Museum_Wikimedia_Commons.jpg",
          "https://upload.wikimedia.org/wikipedia/commons/8/85/Cathedrale_Notre-Dame_de_Paris.jpg"
        ]
      },
      {
        id: 7,
        hotel: "The Peninsula NYC",
        airline: "Delta",
        city: "New York",
        country: "USA",
        price: 700,
        category: "Luxury",
        type: "hotel",
        image: "IMG/The Peninsula NYC.png",
        nearbyAttractions: [
          "https://upload.wikimedia.org/wikipedia/commons/5/5e/Tour_Eiffel_Wikimedia_Commons.jpg",
          "https://upload.wikimedia.org/wikipedia/commons/a/aa/Louvre_Museum_Wikimedia_Commons.jpg",
          "https://upload.wikimedia.org/wikipedia/commons/8/85/Cathedrale_Notre-Dame_de_Paris.jpg"
        ]
      },

      // Voos - Maldivas
      {
        id: 8,
        hotel: "Gili Lankanfushi",
        airline: "Emirates",
        city: "Malé",
        country: "Maldives",
        price: 880,
        category: "Beach",
        type: "flight",
        image: "IMG/Gili Lankanfushi_1.png",
        nearbyAttractions: [
          "https://upload.wikimedia.org/wikipedia/commons/5/5e/Tour_Eiffel_Wikimedia_Commons.jpg",
          "https://upload.wikimedia.org/wikipedia/commons/a/aa/Louvre_Museum_Wikimedia_Commons.jpg",
          "https://upload.wikimedia.org/wikipedia/commons/8/85/Cathedrale_Notre-Dame_de_Paris.jpg"
        ]
      },
      {
        id: 9,
        hotel: "Baros Maldives",
        airline: "Emirates",
        city: "Malé",
        country: "Maldives",
        price: 950,
        category: "Luxury",
        type: "flight",
        image: "IMG/Baros Maldives.png",
        nearbyAttractions: [
          "https://upload.wikimedia.org/wikipedia/commons/5/5e/Tour_Eiffel_Wikimedia_Commons.jpg",
          "https://upload.wikimedia.org/wikipedia/commons/a/aa/Louvre_Museum_Wikimedia_Commons.jpg",
          "https://upload.wikimedia.org/wikipedia/commons/8/85/Cathedrale_Notre-Dame_de_Paris.jpg"
        ]
      }
    ];
  }

  //filtragem
  getMostPicked() {
    return this.spots.slice(0, 8);
  }

  getByCountry(country) {
    return this.spots.filter(s => s.country.toLowerCase() === country.toLowerCase());
  }

  getPersonalized(preferences) {
    return this.spots.filter(s => preferences.some(p => s.category?.includes(p)));
  }

  getPersonalizedByCountry(preferences, country) {
    return this.getPersonalized(preferences).filter(s => s.country.toLowerCase() === country.toLowerCase());
  }

  getAllHotels() {
    return this.spots.filter(s => s.type === "hotel");
  }

  getAllFlights() {
    return this.spots.filter(s => s.type === "flight");
  }
}
