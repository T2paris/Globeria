import TouristicSpotModel from "./Models/TouristicSpotModel.js";
import DestinationView from "./Views/DestinationView.js";
import ModalView from "./Views/ModalView.js";

// iniciar models e views
const model = new TouristicSpotModel();
const view = new DestinationView("mostPickedContainer", "onlyForYouContainer");
const modal = new ModalView("travelModal");

// valor inicial
let selectedPersons = 1;
const userProfile = { preferredCategories: [] }; // assuming this is defined elsewhere

// dados iniciais
const mostPicked = model.getMostPicked();
const personalized = model.getPersonalized(userProfile.preferredCategories);
view.renderMostPicked(mostPicked, (spot) => modal.show(spot, selectedPersons));
view.renderOnlyForYou(personalized, (spot) => modal.show(spot, selectedPersons));

// atualizar contadores
document.getElementById("userCount").textContent = "5241";
document.getElementById("photoCount").textContent = "1294";
document.getElementById("cityCount").textContent = "87";

// botão de pesquisa 
document.getElementById("searchBtn").addEventListener("click", handleSearch);
function handleSearch() {
  const country = document.getElementById("countrySelect").value;
  selectedPersons = Number(document.getElementById("personSelect").value) || 1;
  if (!country) {
    alert("Select a country!");
    return;
  }
  const results1 = model.getByCountry(country);
  const results2 = model.getPersonalizedByCountry(userProfile.preferredCategories, country);
  view.renderMostPicked(results1, (spot) => modal.show(spot, selectedPersons));
  view.renderOnlyForYou(results2, (spot) => modal.show(spot, selectedPersons));
}

function updateBookingTotal(basePrice) {
    const days = parseInt(document.getElementById("bookingDays").value) || 1;
    const packageType = document.getElementById("bookingPackage").value;
  
    let multiplier = 1;
    if (packageType === "flight") multiplier = 0.6;
    if (packageType === "hotel") multiplier = 0.8;
  
    const total = basePrice * days * multiplier;
    document.getElementById("bookingTotal").textContent = `You will pay: $${total.toFixed(2)} USD for `;
    document.getElementById("bookingDayCount").textContent = `${days} Day${days > 1 ? "s" : ""}`;
}
  
document.getElementById("bookingDays").addEventListener("input", () => {
    const price = parseFloat(document.getElementById("modalPrice").textContent.match(/\d+/)[0]);
    updateBookingTotal(price);
});
  
document.getElementById("bookingPackage").addEventListener("change", () => {
    const price = parseFloat(document.getElementById("modalPrice").textContent.match(/\d+/)[0]);
    updateBookingTotal(price);
});
  
  