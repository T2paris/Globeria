import TouristicSpotModel from "./Models/TouristicSpotModel.js";
import DestinationView from "./Views/DestinationView.js";
import ModalView from "./Views/ModalView.js";

const model = new TouristicSpotModel();
const view = new DestinationView("mostPickedContainer");
const modal = new ModalView("travelModal");

let selectedPersons = 1;

// Apenas voos
const allFlights = model.getAllFlights();

view.renderMostPicked(allFlights, spot => modal.show(spot, selectedPersons));

// Botão de busca para voos
document.getElementById("searchBtn").addEventListener("click", handleSearch);
function handleSearch() {
  const country = document.getElementById("countrySelect")?.value || document.getElementById("departureInput")?.value;
  selectedPersons = Number(document.getElementById("passengerSelect")?.value) || 1;
  if (!country) {
    if (typeof showModalAlert === 'function') {
      showModalAlert('Selection Required', 'Please select a country or departure!');
    } else {
      alert("Select a country or departure!");
    }
    return;
  }
  // Filtro only flights
  const results1 = model.getByCountry(country).filter(s => s.type === "flight");
  view.renderMostPicked(results1, (spot) => modal.show(spot, selectedPersons));
  if (results1.length === 0) {
    if (typeof showModalAlert === 'function') {
      showModalAlert('No Results', `No flights found for ${country}`);
    } else {
      alert(`No flights found for ${country}`);
    }
  }
}

// Atualizar contadores
document.getElementById("userCount").textContent = "5241";
document.getElementById("photoCount").textContent = "1294";
document.getElementById("cityCount").textContent = "87";

// Atualiza o valor total de acordo com dias
function updateBookingTotal(basePrice) {
  const days = parseInt(document.getElementById("bookingDays").value) || 1;
  const total = basePrice * days;
  document.getElementById("bookingTotal").textContent =
    `You will pay: $${total.toFixed(2)} USD for `;
  document.getElementById("bookingDayCount").textContent =
    `${days} Day${days > 1 ? "s" : ""}`;
}

document.getElementById("bookingDays").addEventListener("input", () => {
  const price = parseFloat(
    document.getElementById("modalPrice").textContent.match(/\d+(\.\d+)?/)[0]
  );
  updateBookingTotal(price);
});

const travelModal = document.getElementById("travelModal");
const bookingModal = document.getElementById("bookingModal");

travelModal.addEventListener("click", e => {
  if (!e.target.classList.contains("modal-book-btn")) return;
  if (travelModal.classList.contains("hidden")) return;

  // Preencher dados no bookingModal
  const img = document.getElementById("modalMainImage").src;
  const title = document.getElementById("modalTitle").textContent;
  document.getElementById("bookingImage").src = img;
  document.getElementById("bookingTitle").textContent = title;
  document.getElementById("bookingAirline").value = title;
  document.getElementById("bookingDeparture").value = '';
  document.getElementById("bookingArrival").value = '';
  document.getElementById("bookingDate").value = '';
  document.getElementById("bookingPassengers").value = '1';
  document.getElementById("bookingTotal").textContent = '$0 USD';
  travelModal.classList.add('hidden');
  bookingModal.style.display = 'block';
});

document.querySelector("#bookingModal .modal-book-btn").addEventListener("click", function() {
  // Verificar se o utilizador está logado
  const user = JSON.parse(localStorage.getItem('loggedInUser'));
  if (!user) {
    if (typeof showModalAlert === 'function') {
      showModalAlert('Login Required', 'Please log in to save bookings.');
    } else {
      alert("Please log in to save bookings.");
    }
    return;
  }
  // Coletar dados da reserva
  const booking = {
    flight: document.getElementById("bookingTitle").textContent,
    image: document.getElementById("bookingImage").src,
    airline: document.getElementById("bookingAirline").value,
    departure: document.getElementById("bookingDeparture").value,
    arrival: document.getElementById("bookingArrival").value,
    date: document.getElementById("bookingDate").value,
    passengers: document.getElementById("bookingPassengers").value,
    total: document.getElementById("bookingTotal").textContent
  };
  localStorage.setItem('pendingPayment', JSON.stringify(booking));
  window.location.href = 'payment.html';
});

document.getElementById("bookingCloseBtn").onclick = function() {
  bookingModal.style.display = 'none';
};