import TouristicSpotModel from "./Models/TouristicSpotModel.js";
import DestinationView from "./Views/DestinationView.js";
import ModalView from "./Views/ModalView.js";

const model = new TouristicSpotModel();
const view = new DestinationView("mostPickedContainer");
const modal = new ModalView("travelModal");

let selectedPersons = 1;
const allHotels = model.getAllHotels();

view.renderMostPicked(allHotels, spot => modal.show(spot, selectedPersons));

document.getElementById("searchBtn").addEventListener("click", handleSearch);
function handleSearch() {
  const country = document.getElementById("countrySelect")?.value || document.getElementById("destinationInput")?.value;
  selectedPersons = Number(document.getElementById("personSelect").value) || 1;
  if (!country) {
    if (typeof showModalAlert === 'function') {
      showModalAlert('Selection Required', 'Please select a country or destination!');
    } else {
      alert("Select a country or destination!");
    }
    return;
  }
  // Filter only hotels
  const results1 = model.getByCountry(country).filter(s => s.type === "hotel");
  view.renderMostPicked(results1, (spot) => modal.show(spot, selectedPersons));
  
  if (results1.length === 0) {
    if (typeof showModalAlert === 'function') {
      showModalAlert('No Results', `No hotels found for ${country}`);
    } else {
      alert(`No hotels found for ${country}`);
    }
  }
}

// Atualizar contadores
document.getElementById("userCount").textContent = "5241";
document.getElementById("photoCount").textContent = "1294";
document.getElementById("cityCount").textContent = "87";

function updateBookingTotal(basePrice) {
  const days = parseInt(document.getElementById("bookingDays").value) || 1;
  const total = basePrice * days;
  document.getElementById("bookingTotal").textContent =
    `You will pay: $${total.toFixed(2)} USD for `;
  document.getElementById("bookingDayCount").textContent =
    `${days} Day${days > 1 ? "s" : ""}`;
}

document.getElementById("bookingDays").addEventListener("input", () => {
  const price = parseFloat(
    document.getElementById("modalPrice").textContent.match(/\d+(\.\d+)?/)[0]
  );
  updateBookingTotal(price);
});

const travelModal = document.getElementById("travelModal");
const bookingModal = document.getElementById("bookingModal");

travelModal.addEventListener("click", e => {
  if (!e.target.classList.contains("modal-book-btn")) return;
  if (travelModal.classList.contains("hidden")) return;

  // Preencher dados no bookingModal
  const img = document.getElementById("modalMainImage").src;
  const title = document.getElementById("modalTitle").textContent;
  document.getElementById("bookingImage").src = img;
  document.getElementById("bookingTitle").textContent = title;
  document.getElementById("bookingDays").value = 2;
  document.getElementById("bookingCheckIn").value = '';
  document.getElementById("bookingCheckOut").value = '';
  document.getElementById("bookingGuests").value = '1';
  document.getElementById("bookingTotal").textContent = 'You will pay: $0 USD for 2 Days';
  travelModal.classList.add('hidden');
  bookingModal.classList.remove('hidden');
});

document.querySelector("#bookingModal .modal-book-btn").addEventListener("click", function() {
  // Verificar se o utilizador está logado
  const user = JSON.parse(localStorage.getItem('loggedInUser'));
  if (!user) {
    if (typeof showModalAlert === 'function') {
      showModalAlert('Login Required', 'Faz login para guardar reservas.');
    } else {
      alert("Faz login para guardar reservas.");
    }
    return;
  }
  // Coletar dados da reserva
  const booking = {
    hotel: document.getElementById("bookingTitle").textContent,
    image: document.getElementById("bookingImage").src,
    days: parseInt(document.getElementById("bookingDays").value) || 1,
    checkIn: document.getElementById("bookingCheckIn").value,
    checkOut: document.getElementById("bookingCheckOut").value,
    guests: document.getElementById("bookingGuests").value,
    total: document.getElementById("bookingTotal").textContent
  };
  localStorage.setItem('pendingPayment', JSON.stringify(booking));
  window.location.href = 'payment.html';
});

document.getElementById("bookingCloseBtn").onclick = function() {
  bookingModal.classList.add('hidden');
};

// Modal alert function
function showModalAlert(title, message) {
  const alertModal = document.getElementById('alertModal');
  const alertTitle = document.getElementById('alertTitle');
  const alertMessage = document.getElementById('alertMessage');
  const alertOkBtn = document.getElementById('alertOkBtn');
  alertTitle.textContent = title;
  alertMessage.textContent = message;
  alertModal.classList.remove('hidden');
  alertModal.style.display = 'flex';
  // Close modal when OK is clicked
  alertOkBtn.onclick = () => {
    alertModal.classList.add('hidden');
    alertModal.style.display = 'none';
  };
  // Close modal when clicking outside
  alertModal.onclick = (e) => {
    if (e.target === alertModal) {
      alertModal.classList.add('hidden');
      alertModal.style.display = 'none';
    }
  };
}

document.addEventListener('DOMContentLoaded', () => {
  const btn = document.querySelector('.btn-login');
  const userAvatar = document.querySelector('.user-avatar');
  const usernameDisplay = document.getElementById('username-display');
  const user = JSON.parse(localStorage.getItem('loggedInUser'));
  if (user) {
    btn.textContent = 'Logout';
    btn.setAttribute('aria-label','Logout');
    userAvatar.style.display = 'inline-block';
    if (usernameDisplay) usernameDisplay.textContent = user.username || user.name || '';
    userAvatar.onclick = () => {
      window.location.href = '/Html/Perfil.html';
    };
    btn.onclick = () => {
      localStorage.removeItem('loggedInUser');
      window.location.reload();
    };
  } else {
    btn.textContent = 'Login';
    btn.setAttribute('aria-label','Login');
    userAvatar.style.display = 'none';
    if (usernameDisplay) usernameDisplay.textContent = '';
    btn.onclick = () => {
      window.location.href = '/Html/login.html';
    };
  }
});
