// Ensure admin and test user exist in localStorage
(function ensureAdminExists() {
  const usersKey = 'users';
  const users = JSON.parse(localStorage.getItem(usersKey) || '[]');
  // Create admin user if it doesn't exist
  if (!users.some(u => u.role === 'admin')) {
    users.push({
      name: 'Admin',
      email: 'admin@globerio.com',
      phone: '+351912345678',
      country: 'Portugal',
      username: 'admin',
      password: 'admin123',
      role: 'admin'
    });
    console.log('Admin user created');
  }
  // Create a test user if no users exist
  if (users.length === 0) {
    users.push({
      name: 'Test User',
      email: 'test@example.com',
      phone: '+351912345679',
      country: 'Portugal',
      username: 'test',
      password: 'test123',
      role: 'user'
    });
    console.log('Test user created');
  }
  localStorage.setItem(usersKey, JSON.stringify(users));
  console.log('Available users:', users);
})();

// Toggle password visibility
const pwd = document.getElementById('password');
const tog = document.getElementById('togglePassword');
tog.addEventListener('click', () => {
  const isPwd = pwd.type === 'password';
  pwd.type = isPwd ? 'text' : 'password';
  tog.textContent = isPwd ? 'Hide' : 'Show';
});

// Login and validation
const form = document.getElementById('loginForm');
form.addEventListener('submit', e => {
  e.preventDefault();
  // Clear errors
  ['Username','Password'].forEach(field => {
    const inp = document.getElementById(field.toLowerCase());
    const err = document.getElementById('err'+ field);
    inp.classList.remove('is-invalid');
    err.textContent = '';
  });
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  let valid = true;
  if (!username) {
    document.getElementById('username').classList.add('is-invalid');
    document.getElementById('errUsername').textContent = 'Username obrigatório.';
    valid = false;
  }
  if (!password) {
    document.getElementById('password').classList.add('is-invalid');
    document.getElementById('errPassword').textContent = 'Password obrigatória.';
    valid = false;
  }
  if (!valid) return;
  // Fetch users from localStorage
  const users = JSON.parse(localStorage.getItem('users') || '[]');
  console.log('Available users:', users); // Debug
  const user = users.find(u => u.username === username && u.password === password);
  if (!user) {
    document.getElementById('password').classList.add('is-invalid');
    document.getElementById('errPassword').textContent = 'Credenciais inválidas.';
    return;
  }
  console.log('Login successful for user:', user); // Debug
  // Store user data
  localStorage.setItem('loggedInUser', JSON.stringify({
    username: user.username,
    name: user.name,
    role: user.role
  }));
  // Reset form
  form.reset();
  // Redirect immediately
  if (user.role === 'admin') {
    window.location.href = 'Admin.html';
  } else {
    window.location.href = '../index.html';
  }
}); 