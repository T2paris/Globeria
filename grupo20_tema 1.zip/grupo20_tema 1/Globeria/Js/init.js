import TouristicSpotModel from "./Models/TouristicSpotModel.js";
import DestinationView from "./Views/DestinationView.js";
import ModalView from "./Views/ModalView.js";

// iniciar models e views
const model = new TouristicSpotModel();
const view = new DestinationView("mostPickedContainer");
const modal = new ModalView("travelModal");

// Make modal globally accessible
window.modal = modal;

// valor inicial
let selectedPersons = 1;
const userProfile = { preferredCategories: [] }; // assuming this is defined elsewhere

// dados iniciais
const mostPicked = model.getMostPicked();
view.renderMostPicked(mostPicked, (spot) => modal.show(spot, selectedPersons));

// botão de pesquisa 
document.getElementById("searchBtn").addEventListener("click", handleSearch);
function handleSearch() {
  const country = document.getElementById("countrySelect").value;
  selectedPersons = Number(document.getElementById("personSelect").value) || 1;
  if (!country) {
    showModalAlert('Selection Required', 'Please select a country!');
    return;
  }
  const results1 = model.getByCountry(country);
  view.renderMostPicked(results1, (spot) => modal.show(spot, selectedPersons));
}

// Person selector dropdown logic
const personBtn = document.getElementById("person-btn");
const personDropdown = document.getElementById("person-dropdown");
if (personBtn && personDropdown) {
  personBtn.addEventListener("click", () => {
    personDropdown.classList.toggle("hidden");
  });
}
function selectPerson(num) {
  if (personBtn && personDropdown) {
    personBtn.textContent = `Person ${num}`;
    personDropdown.classList.add("hidden");
  }
}
  
