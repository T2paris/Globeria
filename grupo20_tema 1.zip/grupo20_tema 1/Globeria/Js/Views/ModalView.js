// Garante que POINTS_SYSTEM está disponível
if (typeof window !== 'undefined' && !window.POINTS_SYSTEM) {
  window.POINTS_SYSTEM = {
    HOTEL_BOOKING: 10,
    FLIGHT_BOOKING: 10,
    SOCIAL_POST: 5,
    PHOTO_SHARE: 2,
    PROFILE_COMPLETION: 20,
    DAILY_LOGIN: 1,
    REVIEW: 3,
    REFERRAL: 15,
    FIRST_BOOKING: 25,
    SEASONAL_CHALLENGE: 50
  };
}

export default class ModalView {
    constructor(modalId) {
      this.modal = document.getElementById(modalId);
      this.image = document.getElementById("modalMainImage");
      this.title = document.getElementById("modalTitle");
      this.price = document.getElementById("modalPrice");
      this.closeBtn = document.getElementById("modalCloseBtn");
      this.treasureContainer = document.getElementById("treasurePackages");
      this.touristSpots = document.getElementById("touristSpotsGallery");
      this.currentSpot = null;
  
      this.closeBtn.addEventListener("click", () => this.hide());
      this.modal.addEventListener("click", (e) => {
        if (e.target === this.modal) this.hide();
      });
    }
  
    show(spot, persons = 1) {
        console.log('Opening modal for:', spot.hotel);
        this.currentSpot = spot;
        this.image.src = spot.image;
        this.title.textContent = `${spot.hotel} + ${spot.airline}`;
        this.price.textContent = `$${spot.price * persons} for ${persons} ${persons > 1 ? "people" : "person"} • ${spot.city}, ${spot.country}`;
        this.renderTreasures();
        this.renderTouristSpots(spot);
        this.modal.style.display = "block";
        
        // Store the current spot data for booking
        this.currentPersons = persons;
        this.currentBasePrice = spot.price; // Store base price per person
        
        const bookBtn = document.querySelector(".modal-book-btn");
        if (bookBtn) {
            bookBtn.onclick = () => {
                const bookingModal = document.getElementById("bookingModal");
                
                document.getElementById("bookingImage").src = spot.image;
                document.getElementById("bookingTitle").textContent = `${spot.hotel} - ${spot.city}, ${spot.country}`;
                document.getElementById("bookingDays").value = 2;
                document.getElementById("bookingPackage").value = "both";
                document.getElementById("bookingDate").value = "";
                
                // Set default date to tomorrow
                const tomorrow = new Date();
                tomorrow.setDate(tomorrow.getDate() + 1);
                document.getElementById("bookingDate").value = tomorrow.toISOString().split('T')[0];
                
                bookingModal.style.display = "block";
                
                // Close the travel modal
                this.hide();
        
                // Update booking total with the correct price
                this.updateBookingTotal();
                this.setupBookingEventListeners();
                this.setupUserPostSystem();

                // Add redirect to payment page when Book Now is clicked in booking modal
                const bookingBookBtn = bookingModal.querySelector('.modal-book-btn');
                if (bookingBookBtn) {
                  bookingBookBtn.onclick = () => {
                    // Gather booking info
                    const bookingInfo = {
                      hotel: spot.hotel,
                      airline: spot.airline,
                      city: spot.city,
                      country: spot.country,
                      price: spot.price * this.currentPersons,
                      persons: this.currentPersons,
                      date: document.getElementById('bookingDate').value
                    };
                    localStorage.setItem('pendingPayment', JSON.stringify(bookingInfo));
                    window.location.href = 'Html/payment.html';
                  };
                }
            };
        }
        
        // Setup post system immediately when modal opens
        console.log('Setting up post system for modal');
        this.setupUserPostSystem();
    }
  
    hide() {
      this.modal.style.display = "none";
    }

    updateBookingTotal() {
        console.log('=== UPDATE BOOKING TOTAL CALLED ===');
        const daysInput = document.getElementById("bookingDays");
        const packageSelect = document.getElementById("bookingPackage");
        if (!daysInput || !packageSelect) {
            console.error('Could not find days input or package select');
            return;
        }
        const packageType = packageSelect.value;
        const days = parseInt(daysInput.value) || 1;
        let multiplier = 1;
        let basePrice = this.currentBasePrice;
        if (packageType === "flight") {
            multiplier = 0.6;
            basePrice = this.currentBasePrice * 0.6;
        } else if (packageType === "hotel") {
            multiplier = 0.8;
            basePrice = this.currentBasePrice * 0.8;
        } else {
            multiplier = 1;
            basePrice = this.currentBasePrice;
        }
        const total = basePrice * days;
        const totalElement = document.getElementById("bookingTotal");
        const dayCountElement = document.getElementById("bookingDayCount");
        if (totalElement && dayCountElement) {
            const oldText = totalElement.textContent;
            totalElement.textContent = `$${total.toFixed(2)} USD for `;
            if (packageType === "flight") {
                dayCountElement.textContent = "Flight Only";
            } else {
                dayCountElement.textContent = `${days} Day${days > 1 ? "s" : ""}`;
            }
            if (oldText !== totalElement.textContent) {
                totalElement.style.transform = "scale(1.15)";
                totalElement.style.color = "#dc2626";
                totalElement.style.fontWeight = "bold";
                totalElement.style.transition = "all 0.3s ease";
                setTimeout(() => {
                    totalElement.style.transform = "scale(1)";
                    totalElement.style.color = "#92400e";
                    totalElement.style.fontWeight = "normal";
                }, 500);
                const changedElements = [daysInput, packageSelect];
                changedElements.forEach(el => {
                    if (el) {
                        el.style.backgroundColor = "#fef3c7";
                        el.style.borderColor = "#f59e0b";
                        setTimeout(() => {
                            el.style.backgroundColor = "";
                            el.style.borderColor = "";
                        }, 1000);
                    }
                });
            }
            console.log('Price updated successfully:', totalElement.textContent);
        } else {
            console.error('Could not find total or day count elements');
        }
        console.log('=== UPDATE BOOKING TOTAL COMPLETED ===');
    }

    setupBookingEventListeners() {
        const bookingDays = document.getElementById("bookingDays");
        const bookingPackage = document.getElementById("bookingPackage");
        
        console.log('Setting up booking event listeners...');
        
        // Remove existing event listeners by cloning
        if (bookingDays) {
            const newBookingDays = bookingDays.cloneNode(true);
            bookingDays.parentNode.replaceChild(newBookingDays, bookingDays);
            
            // Add new event listeners for days input
            newBookingDays.addEventListener("input", (e) => {
                console.log('Days input event triggered:', e.target.value);
                this.updateBookingTotal();
            });
            
            newBookingDays.addEventListener("change", (e) => {
                console.log('Days change event triggered:', e.target.value);
                this.updateBookingTotal();
            });
            
            // Also add keyup for immediate response
            newBookingDays.addEventListener("keyup", (e) => {
                console.log('Days keyup event triggered:', e.target.value);
                this.updateBookingTotal();
            });
        }
        
        if (bookingPackage) {
            const newBookingPackage = bookingPackage.cloneNode(true);
            bookingPackage.parentNode.replaceChild(newBookingPackage, bookingPackage);
            
            // Add new event listener for package selection
            newBookingPackage.addEventListener("change", (e) => {
                console.log('Package change event triggered:', e.target.value);
                this.updateBookingTotal();
            });
            
            // Also add click event for better compatibility
            newBookingPackage.addEventListener("click", (e) => {
                console.log('Package click event triggered:', e.target.value);
                setTimeout(() => this.updateBookingTotal(), 50);
            });
            
            // Add focus event to ensure we capture all interactions
            newBookingPackage.addEventListener("focus", (e) => {
                console.log('Package focus event triggered:', e.target.value);
            });
        }
        
        // Initial price update with delay to ensure elements are ready
        setTimeout(() => {
            console.log('Initial price update triggered');
            this.updateBookingTotal();
        }, 300);
        
        // Also add a manual trigger button for testing
        this.addManualUpdateButton();

        // Update booking total in real time when details change
        setTimeout(() => {
          const daysInput = document.getElementById('bookingDays');
          const packageSelect = document.getElementById('bookingPackage');
          if (daysInput) {
            daysInput.addEventListener('input', () => this.updateBookingTotal());
            daysInput.addEventListener('change', () => this.updateBookingTotal());
          }
          if (packageSelect) {
            packageSelect.addEventListener('change', () => this.updateBookingTotal());
          }
        }, 500);
    }
    
    addManualUpdateButton() {
        const totalElement = document.getElementById("bookingTotal");
        if (totalElement && !document.getElementById("manualUpdateBtn")) {
            const updateBtn = document.createElement("button");
            updateBtn.id = "manualUpdateBtn";
            updateBtn.textContent = "Update Price";
            updateBtn.style.cssText = `
                background: #10b981;
                color: white;
                border: none;
                padding: 5px 10px;
                border-radius: 4px;
                margin-left: 10px;
                cursor: pointer;
                font-size: 12px;
            `;
            updateBtn.onclick = () => {
                console.log('Manual update button clicked');
                this.updateBookingTotal();
            };
            totalElement.parentNode.appendChild(updateBtn);
        }
    }
  
    renderTreasures() {
      this.treasureContainer.innerHTML = "";
      const treasures = [
        { name: "Spa Package", price: 120 },
        { name: "Romantic Dinner", price: 200 },
        { name: "City Tour", price: 150 }
      ];
  
      treasures.forEach(t => {
        const div = document.createElement("div");
        div.className = "treasure-card";
        div.textContent = `${t.name} - $${t.price}`;
        this.treasureContainer.appendChild(div);
      });
    }
  
    renderTouristSpots(spot) {
        this.touristSpots.innerHTML = "";
        const images = spot.nearbyAttractions || [];
      
        images.forEach(src => {
          const img = document.createElement("img");
          img.src = src;
          img.alt = "Nearby attraction";
          img.style.borderRadius = "8px";
          img.style.width = "100%";
          img.style.objectFit = "cover";
          this.touristSpots.appendChild(img);
        });
    }
      

    setupUserPostSystem() {
        const photoInput = document.getElementById("userPhotoInput");
        const commentInput = document.getElementById("userCommentInput");
        const postBtn = document.getElementById("postUserPhotoBtn");
        const feed = document.getElementById("userPhotosFeed");
      
        console.log('Setting up user post system:', { 
            photoInput: !!photoInput, 
            commentInput: !!commentInput, 
            postBtn: !!postBtn, 
            feed: !!feed 
        });
      
        if (!photoInput || !commentInput || !postBtn || !feed) {
            console.error('Missing elements for user post system');
            return;
        }
      
        // Clear feed
        feed.innerHTML = "";
        
        // Load existing posts for this specific destination
        this.loadExistingPosts(feed);
        
        // Add destination header to the feed
        if (this.currentSpot && this.currentSpot.name) {
            const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
            const username = loggedInUser ? (loggedInUser.username || loggedInUser.name || loggedInUser.email) : null;
            const destinationName = this.currentSpot.name;
            const storageKey = `posts_${username}_${destinationName.replace(/[^a-zA-Z0-9]/g, '_')}`;
            const userPosts = JSON.parse(localStorage.getItem(storageKey)) || [];
            
            const destinationHeader = document.createElement('div');
            destinationHeader.style.cssText = `
                background: linear-gradient(135deg, #1e3a8a, #3b82f6);
                color: white;
                padding: 1rem;
                border-radius: 12px;
                margin-bottom: 1rem;
                text-align: center;
                font-weight: 600;
            `;
            destinationHeader.innerHTML = `
                <h4 style="margin: 0; font-size: 1.1rem;">📸 Posts for ${this.currentSpot.name}</h4>
                <p style="margin: 0.5rem 0 0 0; font-size: 0.9rem; opacity: 0.9;">
                    ${userPosts.length} post${userPosts.length !== 1 ? 's' : ''} • Share your experience at this destination!
                </p>
            `;
            feed.parentNode.insertBefore(destinationHeader, feed);
        }
        
        // Create photo preview container
        const previewContainer = document.createElement('div');
        previewContainer.id = 'photoPreview';
        previewContainer.style.cssText = `
            margin: 1rem 0;
            text-align: center;
            display: none;
        `;
        photoInput.parentNode.insertBefore(previewContainer, photoInput.nextSibling);
      
        // Get logged in user data
        const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
        const user = {
          name: loggedInUser ? (loggedInUser.username || loggedInUser.name || loggedInUser.email || 'Anonymous User') : 'Anonymous User',
          avatar: loggedInUser ? (loggedInUser.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(loggedInUser.username || loggedInUser.name || loggedInUser.email || 'Anonymous')}&background=1e3a8a&color=fff`) : 'https://ui-avatars.com/api/?name=Anonymous&background=1e3a8a&color=fff'
        };
        
        console.log('User data for posts:', user);
      
        // Simple file input handler
        photoInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                console.log('File selected:', file.name, file.size);
                if (!file.type.startsWith('image/')) {
                    alert('Please select an image file.');
                    photoInput.value = '';
                    previewContainer.style.display = 'none';
                    return;
                }
                
                if (file.size > 5 * 1024 * 1024) {
                    alert('Image size should be less than 5MB.');
                    photoInput.value = '';
                    previewContainer.style.display = 'none';
                    return;
                }
                
                // Show preview
                const reader = new FileReader();
                reader.onload = function(e) {
                    previewContainer.innerHTML = `
                        <div style="background: white; padding: 1rem; border-radius: 12px; border: 2px solid #1e3a8a; margin: 1rem 0;">
                            <h4 style="color: #1e3a8a; margin-bottom: 0.5rem;">Photo Preview:</h4>
                            <img src="${e.target.result}" alt="Preview" style="max-width: 200px; max-height: 150px; border-radius: 8px;">
                            <p style="color: #64748b; font-size: 0.8rem; margin-top: 0.5rem;">${file.name}</p>
                        </div>
                    `;
                    previewContainer.style.display = 'block';
                };
                reader.readAsDataURL(file);
            }
        });
      
        // Simple post button handler
        postBtn.onclick = function(e) {
            e.preventDefault();
            console.log('Post button clicked!');
            
            // Check if user is logged in
            if (!loggedInUser) {
                alert('Please login to post your experience!');
                return;
            }
            
            const file = photoInput.files[0];
            const comment = commentInput.value.trim();
      
            console.log('Post data:', { 
                hasFile: !!file, 
                fileName: file ? file.name : 'none',
                comment: comment,
                user: user.name
            });
      
            if (!file && !comment) {
                alert('Please add a photo or write a comment to post.');
                return;
            }
      
            // Create post data object
            const postData = {
                id: Date.now(),
                timestamp: new Date().toISOString(),
                user: user.name,
                avatar: user.avatar,
                comment: comment,
                hasPhoto: !!file,
                fileName: file ? file.name : null
            };
      
            // Create post immediately
            const postDiv = document.createElement("div");
            postDiv.className = "user-photo-card";
            postDiv.style.cssText = `
                background: white;
                border-radius: 15px;
                padding: 1.5rem;
                margin: 1rem 0;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            `;
      
            const timestamp = new Date().toLocaleString();
            
            let postContent = `
                <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 1rem; padding: 0.5rem; background: #f1f5f9; border-radius: 8px;">
                    <img src="${user.avatar}" alt="${user.name}" style="width: 40px; height: 40px; border-radius: 50%;">
                    <div style="display: flex; flex-direction: column; flex-grow: 1;">
                        <strong style="color: #1e3a8a;">${user.name}</strong>
                        <span style="color: #64748b; font-size: 0.7rem;">${timestamp}</span>
                    </div>
                </div>
            `;
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    postContent += `<img src="${e.target.result}" alt="User Photo" style="width: 100%; max-height: 300px; object-fit: cover; border-radius: 12px; margin: 1rem 0;">`;
                    if (comment) {
                        postContent += `<div style="margin-top: 1rem; padding: 1rem; background: #f8fafc; border-radius: 8px; border-left: 4px solid #1e3a8a;"><p style="color: #475569; font-style: italic; margin: 0;">${comment}</p></div>`;
                    }
                    postDiv.innerHTML = postContent;
                    feed.prepend(postDiv);
                    
                    // Save post to localStorage
                    const username = loggedInUser.username || loggedInUser.name || loggedInUser.email;
                    const destinationName = this.currentSpot ? this.currentSpot.name : 'Unknown Destination';
                    const storageKey = `posts_${username}_${destinationName.replace(/[^a-zA-Z0-9]/g, '_')}`;
                    const userPosts = JSON.parse(localStorage.getItem(storageKey)) || [];
                    userPosts.push(postData);
                    localStorage.setItem(storageKey, JSON.stringify(userPosts));
                    
                    console.log('Post saved to localStorage:', {
                        storageKey: storageKey,
                        postData: postData,
                        totalPostsForDestination: userPosts.length,
                        allKeys: Object.keys(localStorage).filter(key => key.startsWith('posts_'))
                    });
                    
                    // Award points for posting
                    this.awardPointsForPost(username);
                    
                    // Update counters
                    this.updateMainPageCounters();
                    
                    // Clear form
                    photoInput.value = '';
                    commentInput.value = '';
                    previewContainer.style.display = 'none';
                    previewContainer.innerHTML = '';
                    
                    // Mensagem de sucesso com pontos corretos
                    let points = 5;
                    if (typeof POINTS_SYSTEM !== 'undefined' && POINTS_SYSTEM.SOCIAL_POST) {
                      points = POINTS_SYSTEM.SOCIAL_POST;
                    }
                    alert(`Post shared successfully! +${points} points awarded!`);
                }.bind(this);
                reader.readAsDataURL(file);
            } else {
                if (comment) {
                    postContent += `<div style="margin-top: 1rem; padding: 1rem; background: #f8fafc; border-radius: 8px; border-left: 4px solid #1e3a8a;"><p style="color: #475569; font-style: italic; margin: 0;">${comment}</p></div>`;
                }
                postDiv.innerHTML = postContent;
                feed.prepend(postDiv);
                
                // Save post to localStorage
                const username = loggedInUser.username || loggedInUser.name || loggedInUser.email;
                const destinationName = this.currentSpot ? this.currentSpot.name : 'Unknown Destination';
                const storageKey = `posts_${username}_${destinationName.replace(/[^a-zA-Z0-9]/g, '_')}`;
                const userPosts = JSON.parse(localStorage.getItem(storageKey)) || [];
                userPosts.push(postData);
                localStorage.setItem(storageKey, JSON.stringify(userPosts));
                
                console.log('Post saved to localStorage:', {
                    storageKey: storageKey,
                    postData: postData,
                    totalPostsForDestination: userPosts.length,
                    allKeys: Object.keys(localStorage).filter(key => key.startsWith('posts_'))
                });
                
                // Award points for posting
                this.awardPointsForPost(username);
                
                // Update counters
                this.updateMainPageCounters();
                
                // Clear form
                commentInput.value = '';
                
                // Mensagem de sucesso com pontos corretos
                let points = 5;
                if (typeof POINTS_SYSTEM !== 'undefined' && POINTS_SYSTEM.SOCIAL_POST) {
                  points = POINTS_SYSTEM.SOCIAL_POST;
                }
                alert(`Post shared successfully! +${points} points awarded!`);
            }
        };
        
        // Enter key support
        commentInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                postBtn.click();
            }
        });
        
        console.log('User post system setup complete');
    }
    
    showPostSuccess() {
        // Create a temporary success message
        const successMsg = document.createElement('div');
        successMsg.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.3);
            z-index: 10000;
            animation: slideInRight 0.3s ease;
        `;
        successMsg.textContent = '✅ Post shared successfully!';
        document.body.appendChild(successMsg);
        
        // Remove after 3 seconds
        setTimeout(() => {
            successMsg.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => {
                document.body.removeChild(successMsg);
            }, 300);
        }, 3000);
    }
    
    // Function to award points for posting
    awardPointsForPost(username) {
        try {
            // Get current user data
            const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
            if (!loggedInUser) {
                console.error('No logged in user found');
                return;
            }
            // Usar o valor correto do sistema de pontos
            let pointsToAward = 5;
            if (typeof POINTS_SYSTEM !== 'undefined' && POINTS_SYSTEM.SOCIAL_POST) {
                pointsToAward = POINTS_SYSTEM.SOCIAL_POST;
            }
            // Update user's points in localStorage
            const currentPoints = parseInt(localStorage.getItem(`points_${username}`)) || 0;
            const newPoints = currentPoints + pointsToAward;
            localStorage.setItem(`points_${username}`, newPoints.toString());
            // Update logged in user object
            loggedInUser.points = newPoints;
            localStorage.setItem('loggedInUser', JSON.stringify(loggedInUser));
            console.log(`Awarded ${pointsToAward} points to ${username}. New total: ${newPoints}`);
            // Update username and ranking display if on main page
            const usernameDisplay = document.getElementById('username-display');
            const userRanking = document.getElementById('user-ranking');
            if (usernameDisplay && userRanking) {
                // Update ranking display
                const ranking = this.calculateUserRanking(loggedInUser);
                const totalPoints = this.calculateTotalPoints(loggedInUser);
                userRanking.textContent = `${ranking} (${totalPoints} pts)`;
            }
        } catch (error) {
            console.error('Error awarding points for post:', error);
        }
    }
    
    // Helper function to calculate user ranking
    calculateUserRanking(user) {
        const totalPoints = this.calculateTotalPoints(user);
        
        if (totalPoints >= 1000) return 'Diamond';
        if (totalPoints >= 500) return 'Platinum';
        if (totalPoints >= 200) return 'Gold';
        if (totalPoints >= 100) return 'Silver';
        if (totalPoints >= 50) return 'Bronze';
        return 'Newcomer';
    }
    
    // Helper function to calculate total points
    calculateTotalPoints(user) {
        const username = user.username || user.name || user.email;
        if (!username) return 0;
        
        const points = parseInt(localStorage.getItem(`points_${username}`)) || 0;
        return points;
    }

    loadExistingPosts(feed) {
        try {
            const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
            if (!loggedInUser) {
                console.log('No logged in user, skipping post loading');
                return;
            }
            
            const username = loggedInUser.username || loggedInUser.name || loggedInUser.email;
            const destinationName = this.currentSpot ? this.currentSpot.name : 'Unknown Destination';
            const storageKey = `posts_${username}_${destinationName.replace(/[^a-zA-Z0-9]/g, '_')}`;
            const userPosts = JSON.parse(localStorage.getItem(storageKey)) || [];
            
            console.log(`Loading ${userPosts.length} existing posts for ${username} at ${destinationName}`);
            
            // Sort posts by timestamp (newest first)
            userPosts.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
            
            userPosts.forEach(post => {
                const postDiv = document.createElement("div");
                postDiv.className = "user-photo-card";
                postDiv.style.cssText = `
                    background: white;
                    border-radius: 15px;
                    padding: 1.5rem;
                    margin: 1rem 0;
                    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                `;
                
                const timestamp = new Date(post.timestamp).toLocaleString();
                
                let postContent = `
                    <div style="display: flex; align-items: center; gap: 0.75rem; margin-bottom: 1rem; padding: 0.5rem; background: #f1f5f9; border-radius: 8px;">
                        <img src="${post.avatar}" alt="${post.user}" style="width: 40px; height: 40px; border-radius: 50%;">
                        <div style="display: flex; flex-direction: column; flex-grow: 1;">
                            <strong style="color: #1e3a8a;">${post.user}</strong>
                            <span style="color: #64748b; font-size: 0.7rem;">${timestamp}</span>
                        </div>
                    </div>
                `;
                
                if (post.hasPhoto) {
                    postContent += `<div style="margin: 1rem 0; padding: 1rem; background: #f8fafc; border-radius: 8px; border-left: 4px solid #1e3a8a;">
                        <p style="color: #475569; font-style: italic; margin: 0;">📷 Photo shared: ${post.fileName}</p>
                    </div>`;
                }
                
                if (post.comment) {
                    postContent += `<div style="margin-top: 1rem; padding: 1rem; background: #f8fafc; border-radius: 8px; border-left: 4px solid #1e3a8a;">
                        <p style="color: #475569; font-style: italic; margin: 0;">${post.comment}</p>
                    </div>`;
                }
                
                postDiv.innerHTML = postContent;
                feed.appendChild(postDiv);
            });
            
            console.log(`Loaded ${userPosts.length} posts successfully for ${destinationName}`);
            
        } catch (error) {
            console.error('Error loading existing posts:', error);
        }
    }
    
    // Direct counter update method
    updateMainPageCounters() {
        try {
            console.log('ModalView: Updating main page counters...');
            
            // Get all users from localStorage
            const users = JSON.parse(localStorage.getItem('users')) || [];
            const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser'));
            
            // Count total users
            let totalUsers = users.length;
            if (loggedInUser && !users.some(u => u.username === loggedInUser.username)) {
                totalUsers++;
            }
            
            // Count total photos from all destinations
            let totalPhotos = 0;
            
            // Count from registered users
            users.forEach(user => {
                const userKeys = Object.keys(localStorage).filter(key => 
                    key.startsWith(`posts_${user.username}_`)
                );
                userKeys.forEach(key => {
                    const userPosts = JSON.parse(localStorage.getItem(key)) || [];
                    totalPhotos += userPosts.length;
                });
            });
            
            // Count from logged in user if not in users array
            if (loggedInUser) {
                const loggedInUserKeys = Object.keys(localStorage).filter(key => 
                    key.startsWith(`posts_${loggedInUser.username}_`)
                );
                loggedInUserKeys.forEach(key => {
                    const loggedInUserPosts = JSON.parse(localStorage.getItem(key)) || [];
                    totalPhotos += loggedInUserPosts.length;
                });
            }
            
            // Count unique cities
            const uniqueCities = new Set();
            const touristSpots = [
                { city: 'Paris', country: 'France' },
                { city: 'Tokyo', country: 'Japan' },
                { city: 'New York', country: 'USA' },
                { city: 'Malé', country: 'Maldives' }
            ];
            
            touristSpots.forEach(spot => {
                uniqueCities.add(spot.city);
            });
            
            const totalCities = uniqueCities.size;
            
            // Update the counter elements
            const userCountEl = document.getElementById("userCount");
            const photoCountEl = document.getElementById("photoCount");
            const cityCountEl = document.getElementById("cityCount");
            
            if (userCountEl) {
                userCountEl.textContent = totalUsers.toString();
                console.log('Updated user count to:', totalUsers);
            }
            if (photoCountEl) {
                photoCountEl.textContent = totalPhotos.toString();
                console.log('Updated photo count to:', totalPhotos);
            }
            if (cityCountEl) {
                cityCountEl.textContent = totalCities.toString();
                console.log('Updated city count to:', totalCities);
            }
            
            console.log('ModalView: Counter update completed:', { totalUsers, totalPhotos, totalCities });
            
        } catch (error) {
            console.error('Error updating counters from ModalView:', error);
        }
    }
}
